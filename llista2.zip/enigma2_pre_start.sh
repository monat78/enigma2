#!/bin/sh
FITXERCONF='/etc/versionactual'
BOUQUETDIR='/etc/enigma2/'
TMPDIR='/tmp/'
URL="https://raw.githubusercontent.com/monat78/enigma2/main/version"
URLLLISTA="https://raw.githubusercontent.com/monat78/enigma2/main/llista.zip"

set +x

# Leer variables desde fichero
if [ -f "$FITXERCONF" ]; then
   source $FITXERCONF
   echo "VERSION="$VERSION
else
   VERSION=1
   printf 'VERSION=1' > $FITXERCONF
fi

RESPONSE=$(curl -s -w "%{HTTP_CODE}" $URL)
HTTP_CODE=$(tail -n1 <<< "$RESPONSE")
CONTENT=$(sed '$ d' <<< "$RESPONSE")

echo "DEBUG"
echo "======================================"
echo "VERSION="$VERSION
echo "CONTENT="$CONTENT
echo "HTTP_CODE="$HTTP_CODE
echo "======================================"

# Funciones extra
urlencode() {
    local length="${#1}"
    local i
    for (( i = 0; i < length; i++ )); do
        local c="${1:i:1}"
        case $c in
            [a-zA-Z0-9.~_-]) printf '%s' "$c" ;;
            ' ') printf '+' ;;
            *) printf '%%%02X' "'$c"
        esac
    done
}

if [[ "$HTTP_CODE" == 200 ]]; then
   if [ "$CONTENT" -gt "$VERSION" ]; then
      echo "ACTUALIZANDO A LA VERSION " $CONTENT
                if [ -d "/etc/enigma2/" ]; then
                   wget --no-check-certificate -r -nv --content-disposition $URLLLISTA -O /tmp/llista.zip
                   unzip -o /tmp/llista.zip -d /etc/enigma2/
				   
				   # Si existe el script, moverlo y dar permisos
                   if [ -f /etc/enigma2/enigma2_pre_start.sh ]; then
                       echo "Moviendo enigma2_pre_start.sh a /usr/bin/"
                       mv -f /etc/enigma2/enigma2_pre_start.sh /usr/bin/enigma2_pre_start.sh
					   echo ----------------------------------------------------
                       echo
                       echo "            ...SCRIPT - UPDATED...                "
                       echo
                       echo ----------------------------------------------------
                       chmod +x /usr/bin/enigma2_pre_start.sh
                   fi
				   
				   # Mover todos los archivos .png a /usr/share/enigma2/picon/
                   if compgen -G "/etc/enigma2/*.png" > /dev/null; then
                       echo "Moviendo archivos .png a /usr/share/enigma2/picon/"
					   mkdir -p /usr/share/enigma2/picon/
                       mv -f /etc/enigma2/*.png /usr/share/enigma2/picon/
					   echo ----------------------------------------------------
                       echo
                       echo "            ...PICONS - UPDATED...                "
                       echo
                       echo ----------------------------------------------------
                   fi
				   
                   rm /tmp/llista.zip
                   wget -qO - http://127.0.0.1/web/servicelistreload?mode=0
                   echo ----------------------------------------------------
                   echo
                   echo "            ...BOUQUETS UPDATED...                "
                   echo
                   echo ----------------------------------------------------
                   echo "VERSION="$VERSION
				   
				   # Si existe fichero de mensaje.txt ejecutarlo
				   FICHERO="/etc/enigma2/mensaje.txt"
				   if [ -f "$FICHERO" ]; then
                       # Leer y convertir el texto a URL-encoded
                       TEXTO=$(cat "$FICHERO" | tr '\n' ' ' | sed 's/  */ /g')
                       MENSAJE=$(urlencode "$TEXTO")
					   # Enviar mensaje con timeout 0 (permanece hasta pulsar OK) y type=2 (mensaje con botón OK)
                       curl -s "http://127.0.0.1/api/message?text=${MENSAJE}&timeout=0&type=2"
					   echo ----------------------------------------------------
                       echo
                       echo "            ...MESSAGE - SENDED...                "
                       echo
                       echo ----------------------------------------------------
                       # Borrar el fichero tras enviar el mensaje
                       rm -f "$FICHERO"
				   fi
                fi
      echo 'VERSION='$CONTENT > $FITXERCONF
   else
      echo "NO HACE FALTA ACTUALIZAR"
      echo "ACTUAL: "$VERSION
      echo "UPDATE: "$CONTENT
   fi
fi

if (crontab -l | grep -q 'enigma2_pre_start.sh'); then
        echo "existeix"
else
        echo "no existeix"
        LINEA="* */6 * * * /usr/bin/enigma2_pre_start.sh"
        (crontab -u $(whoami) -l; echo "$LINEA" ) | crontab -u $(whoami) -
fi

exit
