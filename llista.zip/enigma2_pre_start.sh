#!/bin/sh
FITXERCONF='/etc/versionactual'
BOUQUETDIR='/etc/enigma2/'
TMPDIR='/tmp/'
URL="https://raw.githubusercontent.com/monat78/enigma2/main/version"
URLLLISTA="https://raw.githubusercontent.com/monat78/enigma2/main/llista.zip"
EXECUTE_LAST_URL="https://raw.githubusercontent.com/monat78/enigma2/main/execute_last"

set +x

# Leer variables desde fichero
if [ -f "$FITXERCONF" ]; then
   source $FITXERCONF
   echo "VERSION="$VERSION
else
   VERSION=1
   printf 'VERSION=1' > $FITXERCONF
fi

# Si existe /etc/versionxxx cambiar a segunda lista
if [ -f /etc/versionxxx ]; then
    URLLLISTA="https://raw.githubusercontent.com/monat78/enigma2/main/llistaxxx.zip"
fi

RESPONSE=$(curl -s -w "%{http_code}" $URL)
HTTP_CODE=$(tail -n1 <<< "$RESPONSE")
CONTENT=$(sed '$ d' <<< "$RESPONSE")

RESPONSE2=$(curl -s -w "%{http_code}" $EXECUTE_LAST_URL)
HTTP_CODE2=$(tail -n1 <<< "$RESPONSE2")
CONTENT2=$(sed '$ d' <<< "$RESPONSE2")

echo "DEBUG"
echo "======================================"
echo "VERSION="$VERSION
echo "CONTENT="$CONTENT
echo "EXECUTE_LAST="$CONTENT2
echo "HTTP_CODE="$HTTP_CODE
echo "======================================"

# Funciones extra
urlencode() {
    local length="${#1}"
    local i
    for (( i = 0; i < length; i++ )); do
        local c="${1:i:1}"
        case $c in
            [a-zA-Z0-9.~_-]) printf '%s' "$c" ;;
            ' ') printf '+' ;;
            *) printf '%%%02X' "'$c"
        esac
    done
}

if [[ "$HTTP_CODE" == 200 ]]; then
    if [ "$CONTENT" -gt "$VERSION" ]; then
        echo "ACTUALIZANDO A LA VERSION " $CONTENT
       
        if [ -d "/etc/enigma2/" ]; then
            wget --no-check-certificate -nv --content-disposition $URLLLISTA -O /tmp/llista.zip
           
            if [ -f /tmp/llista.zip ]; then
                unzip -o /tmp/llista.zip -d /etc/enigma2/                
            fi

            if [ -f /etc/enigma2/enigma2_pre_start.sh ]; then
			    echo "Moviendo enigma2_pre_start.sh a /usr/bin/"
                mv -fv /etc/enigma2/enigma2_pre_start.sh /usr/bin/enigma2_pre_start.sh
				chmod +x /usr/bin/enigma2_pre_start.sh
				
                if [ "$HTTP_CODE2" = "200" ]; then
                    if [ "$CONTENT2" = "1" ]; then
                         if [ "$SCRIPT_RELOADED" != "1" ]; then
                             export SCRIPT_RELOADED=1
                             echo "EJECUTANDO SCRIPT PAQUETE ACTUAL..."
                             exec /usr/bin/enigma2_pre_start.sh
                         fi
                    fi
                fi        
                
                echo ----------------------------------------------------
                echo
                echo "            ...SCRIPT - UPDATED...                "
                echo
                echo ----------------------------------------------------
            fi
           
           # Mover todos los archivos .png a /usr/share/enigma2/picon/
           if [ -d /etc/enigma2/picons ] && compgen -G "/etc/enigma2/picons/*.png" > /dev/null; then
               echo "Moviendo archivos .png a /usr/share/enigma2/picon/"
               rm -rf /usr/share/enigma2/picon/
               mkdir -p /usr/share/enigma2/picon/
               mv -fv /etc/enigma2/picons/*.png /usr/share/enigma2/picon/
               rm -rf /etc/enigma2/picons
               rm -f /etc/enigma2/*.png
               echo ----------------------------------------------------
               echo
               echo "            ...PICONS - UPDATED...                "
               echo
               echo ----------------------------------------------------
           fi
           
           rm /tmp/llista.zip
           
           wget -qO - http://127.0.0.1/web/servicelistreload?mode=0
           echo ----------------------------------------------------
           echo
           echo "            ...BOUQUETS UPDATED...                "
           echo
           echo "VERSION="$VERSION                   
           echo ----------------------------------------------------
           
           # Si existe fichero de mensaje.txt ejecutarlo
           FICHERO="/etc/enigma2/mensaje.txt"
           if [ -f "$FICHERO" ]; then
               # Leer y convertir el texto a URL-encoded
               TEXTO=$(cat "$FICHERO" | tr '\n' ' ' | sed 's/  */ /g')
               MENSAJE=$(urlencode "$TEXTO")
               # Enviar mensaje con timeout 0 (permanece hasta pulsar OK) y type=2 (mensaje con botón OK)
               curl -s "http://127.0.0.1/api/message?text=${MENSAJE}&timeout=0&type=2"
               echo ----------------------------------------------------
               echo
               echo "            ...MESSAGE - SENDED...                "
               echo
               echo ----------------------------------------------------
               # Borrar el fichero tras enviar el mensaje
               rm -f "$FICHERO"
           fi
        fi
      echo 'VERSION='$CONTENT > $FITXERCONF
   else
      echo "NO HACE FALTA ACTUALIZAR"
      echo "ACTUAL: "$VERSION
      echo "UPDATE: "$CONTENT
   fi
fi

LINEA_CRONTAB="0 */2 * * * /usr/bin/enigma2_pre_start.sh"
(crontab -l 2>/dev/null | grep -v 'enigma2_pre_start.sh'; echo "$LINEA_CRONTAB") | crontab -

exit
