#!/bin/sh
FITXERCONF='/etc/versionactual'
BOUQUETDIR='/etc/enigma2/'
TMPDIR='/tmp/'
URL="https://raw.githubusercontent.com/monat78/enigma2/main/version"
URLLLISTA="https://raw.githubusercontent.com/monat78/enigma2/main/llista.zip"

set +x

# Leer variables desde fichero
if [ -f "$FITXERCONF" ]; then
   source $FITXERCONF
   echo "VERSION="$VERSION
else
   VERSION=1
   printf 'VERSION=1' > $FITXERCONF
fi

RESPONSE=$(curl -s -w "%{HTTP_CODE}" $URL)
HTTP_CODE=$(tail -n1 <<< "$RESPONSE")
CONTENT=$(sed '$ d' <<< "$RESPONSE")

echo "DEBUG"
echo "======================================"
echo "VERSION="$VERSION
echo "CONTENT="$CONTENT
echo "HTTP_CODE="$HTTP_CODE
echo "======================================"

if [[ "$HTTP_CODE" == 200 ]]; then
   if [ "$CONTENT" -gt "$VERSION" ]; then
      echo "ACTUALIZANDO A LA VERSION " $CONTENT
                if [ -d "/etc/enigma2/" ]; then
                   wget --no-check-certificate -r -nv --content-disposition $URLLLISTA -O /tmp/llista.zip
                   unzip -o /tmp/llista.zip -d /etc/enigma2/
                   rm /tmp/llista.zip
                   wget -qO - http://127.0.0.1/web/servicelistreload?mode=0
                   echo ----------------------------------------------------
                   echo
                   echo "            ...BOUQUETS UPDATED...                "
                   echo
                   echo ----------------------------------------------------
                   echo "VERSION="$VERSION
                fi
      echo 'VERSION='$CONTENT > $FITXERCONF
   else
      echo "NO HACE FALTA ACTUALIZAR"
      echo "ACTUAL: "$VERSION
      echo "UPDATE: "$CONTENT
   fi
fi

if (crontab -l | grep -q 'enigma2_pre_start.sh'); then
        echo "existeix"
else
        echo "no existeix"
        LINEA="* */6 * * * /usr/bin/enigma2_pre_start.sh"
        (crontab -u $(whoami) -l; echo "$LINEA" ) | crontab -u $(whoami) -
fi

exit
